package com.sparkbyexamples.spark.beans

class BooksStruct {

}
