val t = ("A",1,'c')

println(t._1)