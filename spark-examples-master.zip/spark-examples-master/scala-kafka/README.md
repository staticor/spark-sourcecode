Apache Kafka producer and consumer example in scala
