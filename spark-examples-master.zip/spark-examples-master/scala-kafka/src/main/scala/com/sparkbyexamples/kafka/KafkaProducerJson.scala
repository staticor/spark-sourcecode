package com.sparkbyexamples.kafka

object KafkaProducerJson_ {

  def main(args: Array[String]): Unit = {




  }
}
