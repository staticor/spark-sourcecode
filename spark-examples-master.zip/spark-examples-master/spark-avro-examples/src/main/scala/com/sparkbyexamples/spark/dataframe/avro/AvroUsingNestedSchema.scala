package com.sparkbyexamples.spark.dataframe.avro

object AvroUsingNestedSchema_ {

}
