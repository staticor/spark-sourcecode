package com.sparkbyexamples.spark.streaming.inprogress

object SparkStreamingForeachRDD_ {

}
