package com.sparkbyexamples.spark.beans

case class Books(_id:String, author:String, description:String, price:Double, publish_date:String, title:String)