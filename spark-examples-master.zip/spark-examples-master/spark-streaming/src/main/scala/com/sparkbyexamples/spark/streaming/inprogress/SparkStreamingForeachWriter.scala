package com.sparkbyexamples.spark.streaming.inprogress

object SparkStreamingForeachWriter_ {

}
