
var v = 10
val b = 20

println(s"My first value $v  and second value $b")

println(s"Add ${v+b}")
println("a\\b")
println(raw"a\\b")
printf("My first %d and second %d",v,b)